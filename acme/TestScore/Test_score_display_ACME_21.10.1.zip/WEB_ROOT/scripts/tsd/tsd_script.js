/* 
    Test Score Display Customization
    Author: PSUG ACME
    Donated to ACME September 2021
*/
define(['angular', 'components/shared/index'], function (angular) {
	var myApp = angular.module('tsd_module', ['powerSchoolModule']);
	
	myApp.controller('testScoresController', function($scope, $http) {

		$scope.testScores = [];
		$scope.subTests = [];
		$scope.metadata = [];
		$scope.hasData = false;
		$scope.doneLoading = false;
		
		$scope.getTestScores = function(frn, id, name, config, suppress_zero) {
		    
		    $scope.testScores[id] = [];
		    $scope.subTests[id] = [];
		    $scope.metadata[id] = [];
		    testids = config.testid;

			var url = 'tsd_testscores.json';
			if ($scope.portal == 'teachers') url = 'tsd/tsd_testscores_teachers.json';
			if ($scope.portal == 'guardian') url = 'tsd/tsd_testscores_guardian.json';

    		$http.get(url + '?no-store-lp=1&frn=' + frn 
    		            + '&testids=' + testids 
    		            + '&desc=' + $scope.sort_desc
    		            + '&suppress_zero=' + suppress_zero).then(function(retJSON) {
    		    retJSON.data.pop();

				$scope.numTests --;
				console.log('numTests=' + $scope.numTests);
				if($scope.numTests == 0) {
					$scope.doneLoading = true;
					// loadingDialog fired by view
					closeLoading();
				}
    		    var results = {};
    		    var headers = {};
    		    var nodata = true;
    		    
    		    // pivot subscores for unique test date (YYDDD as key)
    		    retJSON.data.forEach( function(row) {

    		        // create the row key for pivoting
    		        var key = row.test_key;
    		        results[key] = results[key] || {}; // this makes the results[key] an object, if not already one
    		        
    		        // add in the grouped values for each unique row
    		        results[key]['studentsdcid'] = row.studentsdcid;
    		        results[key]['student_test_id'] = row.student_test_id;
    		        results[key]['test_date'] = row.test_date;
    		        results[key]['grade_level'] = row.grade_level;
    		        results[key]['test_name'] = row.test_name;
    		        results[key]['sub_scores'] = results[key]['sub_scores'] || {};
    		        
    		        // is this subtest selected for display?  num, pct, or abc
    		        if( config.subtests[row.subtest_id].num || config.subtests[row.subtest_id].pct || config.subtests[row.subtest_id].abc ) {

    		            // set nodata to false
    		            nodata = false;
    		            
        		        // add in the pivoted values based on subtest_key (as column)
        		        var column = row.subtest_key;
    		            if (config.subtests[row.subtest_id].head) {
    		                // set alternate column header key if selected in the config
    		                row.subtest_name = config.subtests[row.subtest_id].head;
    		                column = config.subtests[row.subtest_id].head.replace(/[^0-9a-z]/gi, '');
    		            }

        		        var scores = { 'subject_name':row.subtest_name,
        		                       'is_num': config.subtests[row.subtest_id].num,
        		                       'numscore':row.numscore,
        		                       'is_pct': config.subtests[row.subtest_id].pct,
        		                       'is_sym': config.subtests[row.subtest_id].sym,
        		                       'pctscore':row.percentscore,
        		                       'is_abc': config.subtests[row.subtest_id].abc,
        		                       'abcscore':row.alphascore
        		                     };
        		        results[key]['sub_scores'][column] = scores;
        		        
        		        // copy subtest_name to headers array
        		        headers[column] = headers[column] || {}; // this makes the headers[column] an object, if not already one
        		        headers[column]['key'] = column;
        		        if (config.subtests[row.subtest_id].head) {
        		            // set alternate column header label if selected in the config
        		            headers[column]['name'] = config.subtests[row.subtest_id].head;
        		        } else {
        		            headers[column]['name'] = row.subtest_name;
        		        }

    		        }

    		    });

                $scope.testScores[id] = results;
                $scope.subTests[id] = headers;
                $scope.metadata[id].name = name;
				$scope.metadata[id].allowAdmin = config.allowAdmin;
				$scope.metadata[id].allowTeachers = config.allowTeachers;
				$scope.metadata[id].allowGuardian = config.allowGuardian;
                $scope.metadata[id].gridfoot = config.gridfoot.replace(/\n/g,"<br>");
                $scope.metadata[id].nodata = nodata;
				console.log('portal=' + $scope.portal);
				// set model to control display of no data message
				console.log('nodata=' + nodata);
				console.log($scope);
				console.log(config);
				if(
					!nodata && 
					( 
						(config.allowTeachers == 1 && $scope.portal == 'teachers') || 
						(config.allowGuardian == 1 && $scope.portal == 'guardian') ||
						(config.allowAdmin == 1 && $scope.portal == 'admin')
					) 
				) $scope.hasData = true;


    		});
		};

		$scope.getSetup = function(schoolid, frn)  {
		    
			var url = 'tsd_setup.json';
			if ($scope.portal == 'teachers') url = '/teachers/studentpages/tsd/tsd_setup_teachers.json';
			if ($scope.portal == 'guardian') url = 'tsd/tsd_setup_guardian.json';

            // get setup and loop through each configuration
            $http.get(url + '?schoolid=' + schoolid).then(function(retJSON) {
                retJSON.data.pop();
				$scope.numTests = retJSON.data.length;
				if($scope.numTests == 0) {
					$scope.doneLoading = true;
					// close loadingDialog if no tests - dialog started by view
					closeLoading();
				}
				console.log('numTests=' + $scope.numTests);
                retJSON.data.forEach( function(row) {

                    // call the getTestScores for each grid
                    $scope.getTestScores(frn, row.config_id, row.config_name, row.config, row.config_suppress_zero);
                    
                });
            });

		}		

	});

});
